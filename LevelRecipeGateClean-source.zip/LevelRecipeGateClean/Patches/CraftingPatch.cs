using System;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using ProjectM;
using ProjectM.Network;
using LevelRecipeGate.Config;
using Stunlock.Core;
using Unity.Collections;
using Unity.Entities;

namespace LevelRecipeGate.Patches
{
	[HarmonyPatch(typeof(StartCraftingSystem), "OnUpdate")]
	public static class CraftingPatch
	{
		[HarmonyPrefix]
		public static void Prefix(StartCraftingSystem __instance)
		{
			EntityManager entityManager = __instance.EntityManager;
			EntityQuery entityQuery;

			try
			{
				FieldInfo field = typeof(StartCraftingSystem).GetField("_StartCraftItemEventQuery", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
				entityQuery = (((field != null ? field.GetValue(__instance) : null) as EntityQuery?) ?? entityManager.CreateEntityQuery(new EntityQueryDesc[]
				{
					new EntityQueryDesc
					{
						All = new ComponentType[]
						{
							ComponentType.ReadOnly<FromCharacter>(),
							ComponentType.ReadOnly<StartCraftItemEvent>()
						},
						Options = (EntityQueryOptions)2
					}
				}));
			}
			catch (Exception ex)
			{
				Plugin.Logger.LogWarning($"[{Plugin.Name}] Failed creating craft query: {ex.Message}");
				return;
			}

			NativeArray<Entity> entities = default(NativeArray<Entity>);

			try
			{
				entities = entityQuery.ToEntityArray(Allocator.Temp);

				for (int i = 0; i < entities.Length; i++)
				{
					Entity eventEntity = entities[i];

					if (!entityManager.HasComponent<StartCraftItemEvent>(eventEntity))
						continue;

					StartCraftItemEvent craftEvent = entityManager.GetComponentData<StartCraftItemEvent>(eventEntity);

					if (!TryGetRecipeGuid(craftEvent, out PrefabGUID recipeGuid))
						continue;

					if (!ConfigStore.TryGetRequiredLevel(recipeGuid.GuidHash, out int requiredLevel))
						continue;

					int playerLevel = TryGetCraftingPlayerLevel(entityManager, eventEntity);

					// This line is intentionally useful for first testing.
					Plugin.Logger.LogInfo($"[{Plugin.Name}] Craft check recipe={recipeGuid.GuidHash}, playerLevel={playerLevel}, requiredLevel={requiredLevel}");

					// Safety rule: if the mod cannot read player level, block the craft instead of allowing bypass.
					if (playerLevel < requiredLevel)
					{
						entityManager.DestroyEntity(eventEntity);

						string message = ConfigStore.LevelRecipeBlockedMessage
							.Replace("{level}", requiredLevel.ToString())
							.Replace("{current}", playerLevel >= 0 ? playerLevel.ToString() : "unknown")
							.Replace("{recipe}", recipeGuid.GuidHash.ToString());

						TrySendSystemMessage(entityManager, eventEntity, message);

						Plugin.Logger.LogInfo($"[{Plugin.Name}] BLOCKED recipe={recipeGuid.GuidHash}, playerLevel={playerLevel}, requiredLevel={requiredLevel}");
					}
					else
					{
						Plugin.Logger.LogInfo($"[{Plugin.Name}] ALLOWED recipe={recipeGuid.GuidHash}, playerLevel={playerLevel}, requiredLevel={requiredLevel}");
					}
				}
			}
			finally
			{
				if (entities.IsCreated)
					entities.Dispose();
			}
		}

		private static int TryGetCraftingPlayerLevel(EntityManager entityManager, Entity eventEntity)
		{
			try
			{
				if (!entityManager.HasComponent<FromCharacter>(eventEntity))
					return -1;

				FromCharacter fromCharacter = entityManager.GetComponentData<FromCharacter>(eventEntity);

				// Try the character first.
				int characterLevel = TryGetLevelFromEntity(entityManager, fromCharacter.Character);
				if (characterLevel >= 0)
					return characterLevel;

				// Some versions/store mods may put useful level data on the User entity.
				int userLevel = TryGetLevelFromEntity(entityManager, fromCharacter.User);
				if (userLevel >= 0)
					return userLevel;
			}
			catch (Exception ex)
			{
				Plugin.Logger.LogWarning($"[{Plugin.Name}] Failed reading crafting player level: {ex.Message}");
			}

			return -1;
		}

		private static int TryGetLevelFromEntity(EntityManager entityManager, Entity entity)
		{
			if (entity == Entity.Null || !entityManager.Exists(entity))
				return -1;

			// First try common known component names.
			string[] preferredComponentTypeNames =
			{
				"ProjectM.Equipment, ProjectM",
				"ProjectM.UnitLevel, ProjectM",
				"ProjectM.Level, ProjectM",
				"ProjectM.PlayerLevel, ProjectM",
				"ProjectM.CharacterLevel, ProjectM",
				"ProjectM.GearLevel, ProjectM"
			};

			foreach (string typeName in preferredComponentTypeNames)
			{
				Type componentType = Type.GetType(typeName);
				if (componentType == null)
					continue;

				object component = TryGetComponentDataBoxed(entityManager, entity, componentType);
				if (component == null)
					continue;

				int level = TryExtractLevelValue(component);
				if (level >= 0)
				{
					Plugin.Logger.LogInfo($"[{Plugin.Name}] Level source: {componentType.FullName} => {level}");
					return level;
				}
			}

			// Fallback: scan all components on the entity and look for likely level fields.
			NativeArray<ComponentType> componentTypes = default(NativeArray<ComponentType>);
			try
			{
				componentTypes = entityManager.GetComponentTypes(entity, Allocator.Temp);

				for (int i = 0; i < componentTypes.Length; i++)
				{
					Type managedType = TryGetManagedType(componentTypes[i]);
					if (managedType == null)
						continue;

					string name = managedType.FullName ?? managedType.Name;
					if (name.IndexOf("Level", StringComparison.OrdinalIgnoreCase) < 0 &&
					    name.IndexOf("Equipment", StringComparison.OrdinalIgnoreCase) < 0 &&
					    name.IndexOf("Gear", StringComparison.OrdinalIgnoreCase) < 0)
						continue;

					object component = TryGetComponentDataBoxed(entityManager, entity, managedType);
					if (component == null)
						continue;

					int level = TryExtractLevelValue(component);
					if (level >= 0)
					{
						Plugin.Logger.LogInfo($"[{Plugin.Name}] Level source scan: {name} => {level}");
						return level;
					}
				}
			}
			catch
			{
			}
			finally
			{
				if (componentTypes.IsCreated)
					componentTypes.Dispose();
			}

			return -1;
		}

		private static Type TryGetManagedType(ComponentType componentType)
		{
			try
			{
				MethodInfo method = typeof(ComponentType).GetMethod("GetManagedType", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
				if (method == null)
					return null;

				return method.Invoke(componentType, null) as Type;
			}
			catch
			{
				return null;
			}
		}

		private static object TryGetComponentDataBoxed(EntityManager entityManager, Entity entity, Type componentType)
		{
			try
			{
				MethodInfo hasComponent = typeof(EntityManager).GetMethods()
					.FirstOrDefault(m => m.Name == "HasComponent" && m.IsGenericMethodDefinition && m.GetParameters().Length == 1);

				MethodInfo getComponent = typeof(EntityManager).GetMethods()
					.FirstOrDefault(m => m.Name == "GetComponentData" && m.IsGenericMethodDefinition && m.GetParameters().Length == 1);

				if (hasComponent == null || getComponent == null)
					return null;

				bool has = (bool)hasComponent.MakeGenericMethod(componentType).Invoke(entityManager, new object[] { entity });
				if (!has)
					return null;

				return getComponent.MakeGenericMethod(componentType).Invoke(entityManager, new object[] { entity });
			}
			catch
			{
				return null;
			}
		}

		private static int TryExtractLevelValue(object component)
		{
			if (component == null)
				return -1;

			Type type = component.GetType();

			string[] preferredNames =
			{
				"GearLevel",
				"EquipmentLevel",
				"TotalGearLevel",
				"TotalLevel",
				"CharacterLevel",
				"UnitLevel",
				"Level",
				"Value",
				"_Level",
				"value"
			};

			foreach (string name in preferredNames)
			{
				FieldInfo field = type.GetField(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
				if (field != null && TryConvertToInt(field.GetValue(component), out int fieldValue))
					return fieldValue;

				PropertyInfo property = type.GetProperty(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
				if (property != null && property.GetIndexParameters().Length == 0 && TryConvertToInt(property.GetValue(component), out int propertyValue))
					return propertyValue;
			}

			foreach (FieldInfo field in type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
			{
				if ((field.Name.IndexOf("level", StringComparison.OrdinalIgnoreCase) >= 0 ||
				     field.Name.IndexOf("gear", StringComparison.OrdinalIgnoreCase) >= 0) &&
				    TryConvertToInt(field.GetValue(component), out int value))
					return value;
			}

			return -1;
		}

		private static bool TryConvertToInt(object value, out int result)
		{
			result = -1;

			if (value == null)
				return false;

			try
			{
				if (value is int i) { result = i; return true; }
				if (value is short s) { result = s; return true; }
				if (value is byte b) { result = b; return true; }
				if (value is float f) { result = (int)Math.Floor(f); return true; }
				if (value is double d) { result = (int)Math.Floor(d); return true; }

				return int.TryParse(value.ToString(), out result);
			}
			catch
			{
				return false;
			}
		}

		private static bool TryGetRecipeGuid(StartCraftItemEvent ev, out PrefabGUID guid)
		{
			Type eventType = typeof(StartCraftItemEvent);
			object boxed = ev;

			string[] preferredNames =
			{
				"RecipePrefab",
				"Recipe",
				"RecipeGuid",
				"RecipePrefabGuid",
				"m_Recipe",
				"_Recipe"
			};

			foreach (string name in preferredNames)
			{
				FieldInfo field = eventType.GetField(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
				if (field != null && field.FieldType == typeof(PrefabGUID))
				{
					guid = (PrefabGUID)field.GetValue(boxed);
					return true;
				}
			}

			foreach (FieldInfo field in eventType.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
			{
				if (field.FieldType == typeof(PrefabGUID))
				{
					guid = (PrefabGUID)field.GetValue(boxed);
					return true;
				}
			}

			guid = default(PrefabGUID);
			return false;
		}

		private static void TrySendSystemMessage(EntityManager entityManager, Entity eventEntity, string message)
		{
			try
			{
				if (!entityManager.HasComponent<FromCharacter>(eventEntity))
					return;

				FromCharacter fromCharacter = entityManager.GetComponentData<FromCharacter>(eventEntity);
				if (fromCharacter.User == Entity.Null || !entityManager.Exists(fromCharacter.User) || !entityManager.HasComponent<User>(fromCharacter.User))
					return;

				User user = entityManager.GetComponentData<User>(fromCharacter.User);
				FixedString512Bytes fixedMessage = message;

				Type chatUtils = Type.GetType("ProjectM.Network.ServerChatUtils, ProjectM") ??
				                 Type.GetType("ProjectM.ServerChatUtils, ProjectM");

				if (chatUtils == null)
					return;

				MethodInfo method = chatUtils.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)
					.FirstOrDefault(m => m.Name == "SendSystemMessageToClient" && m.GetParameters().Length == 3);

				if (method == null)
					return;

				object[] args = new object[] { entityManager, user, fixedMessage };
				method.Invoke(null, args);
			}
			catch (Exception ex)
			{
				Plugin.Logger.LogWarning($"[{Plugin.Name}] Could not send system message: {ex.Message}");
			}
		}
	}
}
